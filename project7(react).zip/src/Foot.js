export default function Foot() {
  return (
    <section className='foot container'>
      <p className="text-center text-white py-3">2045 All Rights Reserved. By HTML Design </p>
    </section>
  );
}